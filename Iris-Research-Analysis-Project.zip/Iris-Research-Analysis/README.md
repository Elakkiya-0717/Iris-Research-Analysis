# Iris Research Analysis

Research question: Is mean petal length different among Iris setosa, versicolor, and virginica?

## Dataset
The notebook loads the classic Iris dataset using `sklearn.datasets.load_iris`; no separate raw CSV is needed. It validates the data, summarizes petal length, runs one-way ANOVA, reports diagnostics, and runs Tukey HSD if the overall ANOVA is significant.

## Files
- `preregistration.md`: planned hypotheses, variables, exclusions, and analysis.
- `notebooks/analysis.ipynb`: reproducible Python analysis.
- `reports/research_report.md`: fill-in report template; use actual notebook outputs.
- `tests/test_pipeline.py`: tests using synthetic data only.
- `requirements-lock.txt`: pinned package versions.

## Setup
Python 3.11+ recommended:
```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements-lock.txt
```
Run the notebook top to bottom in Jupyter. Run tests with `pytest -q`.

Before submission, run the notebook, fill the report using its real outputs, and confirm the tests pass. Do not invent results.
